import sys
import traceback
from datetime import datetime
from http import HTTPStatus
from aiohttp import web
from aiohttp.web import Request, Response, json_response
from botbuilder.core import (
    TurnContext,
)
from botbuilder.core.integration import aiohttp_error_middleware
from botbuilder.integration.aiohttp import CloudAdapter, ConfigurationBotFrameworkAuthentication
from botbuilder.schema import Activity, ActivityTypes
from config import DefaultConfig
CONFIG = DefaultConfig()
ADAPTER = CloudAdapter(ConfigurationBotFrameworkAuthentication(CONFIG))
from botbuilder.core import ActivityHandler, TurnContext
from azure.core.credentials import AzureKeyCredential
from azure.ai.textanalytics import TextAnalyticsClient
class EchoBot(ActivityHandler):
    def __init__(self, endpoint, key):
        # Initialize the Text Analytics client
        self.text_analytics_client = TextAnalyticsClient(
            endpoint=endpoint, credential=AzureKeyCredential(key)
        )
    async def on_message_activity(self, turn_context: TurnContext):
        # Get the user message
        user_message = turn_context.activity.text
        # Analyzing sentiment
        documents = [user_message]
        result = self.text_analytics_client.analyze_sentiment(
            documents, show_opinion_mining=True
        )
        sentiment = result[0].sentiment  # Overall sentiment (positive, neutral, negative)
        response = f"The sentiment of your message is: {sentiment.capitalize()}."
        await turn_context.send_activity(response)

# Azure Text Analytics credentials
endpoint = 'https://t6languageservice.cognitiveservices.azure.com/'  # Replace with your Azure endpoint
key = 'A64AFST57Djz9kB8ZfoNKVPGIpHCpOqbNSc24luorpdUurYheQl2JQQJ99BAACYeBjFXJ3w3AAAaACOGMrpq'  # Replace with your Azure key
BOT = EchoBot(endpoint=endpoint, key=key)
async def on_error(context: TurnContext, error: Exception):
    print(f"\n [on_turn_error] unhandled error: {error}", file=sys.stderr)
    traceback.print_exc()

    await context.send_activity("The bot encountered an error or bug.")
    await context.send_activity(
        "Please try again later. If the issue persists, contact support."
    )
async def messages(req: Request) -> Response:
    return await ADAPTER.process(req, BOT)

APP = web.Application(middlewares=[aiohttp_error_middleware])
APP.router.add_post("/api/messages", messages)

if __name__ == "__main__":
    try:
        web.run_app(APP, host="localhost", port=CONFIG.PORT)
    except Exception as error:
        raise error